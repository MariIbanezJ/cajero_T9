package prog09;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Ejercicio 9 Programa Menú del programa para la interaccion con el usuario
 *
 * @author Juan Marí Ibáñez Fecha última modificación: 20.03.2022
 */
public class Menu {

    public static int menu() {
        int numero = 0;

        System.out.println("\n----------------------------------------------------");
        System.out.println("               Menú de Opciones ");
        System.out.println("----------------------------------------------------");
        System.out.println("1. Abrir una nueva cuenta.");
        System.out.println("2. Ver listado de cuentas disponibles.");
        System.out.println("3. Obtener datos de una cuenta.");
        System.out.println("4. Realizar ingreso en una cuenta.");
        System.out.println("5. Retirar efectivo de una cuenta.");
        System.out.println("6. Consultar el saldo actual de una cuenta.");
        System.out.println("7. Eliminar Cuenta Bancaria.");
        System.out.println("8. Mostrar numero de Cuentas Ahorro.");
        System.out.println("9. Mostrar saldo acumulado de Cuentas Corrientes.");
        System.out.println("10. Mostrar 3 primeras Cuentas con mayor saldo.");
        System.out.println("11. Listado de Clientes.");
        System.out.println("12. Salir de la aplicación.");
        System.out.println("----------------------------------------------------");
        System.out.print("Introduzca una opción: ");

        try {
            Scanner sc = new Scanner(System.in);
            numero = sc.nextInt();
        } catch (InputMismatchException e) {

        }

        return numero;
    }

}//Fin Clase
