package prog09;

import java.util.InputMismatchException;
import java.util.*;
import java.util.regex.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Ejercicio: 9 Práctica Persistencia de Datos
 *
 * @author Juan Marí Ibáñez Fecha última modificación: 20.03.2022
 */
public class Prog09 {

    public static void main(String[] args) {

        int opcion;//Variable que almacena numero de opción
        Pattern patronIBAN = Pattern.compile("(ES[0-9]{22})");//Expresión regular IBAN
        Pattern patronDNI = Pattern.compile("(0-9)[7-8](A-Z a-z)[1]");//Expresión regular DNI
        ListaCuentas listaCuentas = new ListaCuentas();//Estructura de almacenamiento

        listaCuentas.cargaArray();
        

        do {

            opcion = Menu.menu();

            switch (opcion) {

                ///////////////Abrir una nueva cuenta///////////////////////////
                case 1: {
                    //Apellidos
                    String nombre = dameNombre();

                    //Nombre
                    String apellidos = dameApellidos();

                    //DNI
                    String DNI;
                    Persona cliente = null;
                    Dni DNICliente = null;
                    DNI = Dni.dameDNI();
                    DNICliente = new Dni(DNI);

                    try {
                        cliente = new Persona(nombre, apellidos, DNICliente);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }

                    //IBAN
                    String IBAN = listaCuentas.crearIBAN();

                    //Saldo Inicial
                    double saldoInicial = dameSaldoInicial();

                    //Tipo de Cuenta
                    int tipoCuenta = tipoCuenta();

                    switch (tipoCuenta) {
                        //*********************CuentaCorriente******************
                        case 1: {
                            CuentaBancaria cuentaCorriente = creaCuentaCorriente(cliente, saldoInicial, IBAN);
                            listaCuentas.abrirCuenta(cuentaCorriente);
                            System.out.println("----------------------------------------------------\n"
                                    + "              CUENTA CREADA CON ÉXITO\n"
                                    + "----------------------------------------------------\n");

                            break;
                        }
                        //**********************CuentaAhorro********************
                        case 2: {
                            CuentaBancaria cuentaAhorro = creaCuentaAhorro(cliente, saldoInicial, IBAN);
                            listaCuentas.abrirCuenta(cuentaAhorro);

                            System.out.println("----------------------------------------------------\n"
                                    + "              CUENTA CREADA CON ÉXITO\n"
                                    + "----------------------------------------------------\n");

                            break;
                        }
                        //*******************Opción por Defecto*****************
                        default: {
                            System.out.println("----------------------------------------------------\n"
                                    + "    ERROR: DEBE INTRODUCIR UNA OPCIÓN VÁLIDA\n"
                                    + "----------------------------------------------------\n");

                            break;
                        }

                    }

                    break;
                }

                ///////////////Ver listado de cuentas disponibles.//////////////
                case 2: {
                    System.out.println("\n----------------------------------------------------\n"
                            + "   LISTADO DE CUENTAS BANCARIAS ALMACENADAS\n"
                            + "----------------------------------------------------\n");

                    listaCuentas.listadoCuentas();
                    break;

                }

                //////////////////Obtener datos de una cuenta///////////////////
                case 3: {
                    boolean existeIBAN = false;
                    boolean IBANOK = false;
                    String IBAN = "";

                    IBAN = Utilidades.compruebaIBAN();
                    existeIBAN = listaCuentas.existeIBAN(IBAN);

                    if (existeIBAN == false) {
                        System.out.println("\n----------------------------------------------------\n"
                                + "ERROR!! NO SE ENCUENTRA LA CUENTA ASOCIADA AL IBAN:\n "
                                + "           " + IBAN
                                + "\n----------------------------------------------------\n");
                    } else if (existeIBAN == true) {
                        String datosCuenta = "\n" + listaCuentas.informacionCuenta(IBAN) + "\n";
                        System.out.println("\n----------------------------------------------------\n"
                                + "INFORMACIÓN DE LA CUENTA: \n " + datosCuenta);

                        System.out.println("\n----------------------------------------------------\n");

                    }

                    break;

                }

                ////////////// Realizar ingreso en una cuenta///////////////////
                case 4: {

                    boolean continuaCantidadIngresar = false;
                    double cantidadIngresar = 0;

                    boolean existeIBAN = false;
                    boolean IBANOK = false;
                    String IBAN = "";

                    do {
                        IBAN = Utilidades.compruebaIBAN();
                        existeIBAN = listaCuentas.existeIBAN(IBAN);

                        if (existeIBAN == false) {
                            System.out.println("\n----------------------------------------------------\n"
                                    + "ERROR!! NO SE ENCUENTRA LA CUENTA ASOCIADA AL IBAN:\n "
                                    + "           " + IBAN
                                    + "\n----------------------------------------------------\n");
                        } else if (existeIBAN == true) {
                            IBANOK = true;
                        }
                    } while (IBANOK == false);

                    do {
                        try {
                            cantidadIngresar = Utilidades.llegirDouble("INTRODUZCA LA CANTIDAD QUE DESEA INGRESAR: ");
                        } catch (InputMismatchException e) {
                            System.out.println("----------------------------------------------------\n"
                                    + "      ERROR: ENTRADA DE DATOS NO COMPATIBLE\n"
                                    + "----------------------------------------------------\n");
                        }

                        if (cantidadIngresar > 0) {
                            continuaCantidadIngresar = true;
                        }

                        if (cantidadIngresar <= 0) {
                            System.out.println("----------------------------------------------------\n"
                                    + "      ERROR: DEBE INTRODUCIR UN VALOR POSITIVO\n"
                                    + "----------------------------------------------------\n");
                        }

                    } while (continuaCantidadIngresar == false);

                    boolean ingreso = listaCuentas.ingresoCuenta(IBAN, cantidadIngresar);

                    if (ingreso == true) {
                        System.out.println("----------------------------------------------------\n"
                                + "INGRESO REALIZADO EN LA CUENTA ASOCIADA AL IBAN:\n "
                                + IBAN);
                        System.out.println("\n----------------------------------------------------\n"
                                + "SU SAlDO ACTUAL ES:: " + listaCuentas.obtenerSaldo(IBAN) + "\n");

                    } else if (ingreso == false) {
                        System.out.println("----------------------------------------------------\n"
                                + "NO SE HA PODIDO REALIZAR EL INGRESO EN LA CUENTA CON IBAN:\n "
                                + IBAN);

                    }

                    break;

                }

                //////////////Retirar efectivo de una cuenta////////////////////
                case 5: {

                    double cantidadRetirar = 0;
                    boolean continuaCantidadRetirar = false;

                    boolean existeIBAN = false;
                    boolean IBANOK = false;
                    String IBAN = "";

                    do {
                        IBAN = Utilidades.compruebaIBAN();
                        existeIBAN = listaCuentas.existeIBAN(IBAN);

                        if (existeIBAN == false) {
                            System.out.println("\n----------------------------------------------------\n"
                                    + "ERROR!! NO SE ENCUENTRA LA CUENTA ASOCIADA AL IBAN:\n "
                                    + "           " + IBAN
                                    + "\n----------------------------------------------------\n");
                        } else if (existeIBAN == true) {
                            IBANOK = true;
                        }
                    } while (IBANOK == false);

                    do {

                        try {

                            cantidadRetirar = Utilidades.llegirDouble("INTRODUZCA LA CANTIDAD QUE DESEA RETIRAR: ");
                        } catch (InputMismatchException e) {
                            System.out.println("\n----------------------------------------------------\n"
                                    + "      ERROR: ENTRADA DE DATOS NO COMPATIBLE\n"
                                    + "----------------------------------------------------\n");
                        }

                        if (cantidadRetirar > 0) {
                            continuaCantidadRetirar = true;
                        }
                        if (cantidadRetirar <= 0) {
                            System.out.println("\n----------------------------------------------------\n"
                                    + "      ERROR: DEBE INTRODUCIR UN VALOR POSITIVO\n"
                                    + "----------------------------------------------------\n");
                        }

                    } while (continuaCantidadRetirar == false);

                    boolean retirada = listaCuentas.retiradaCuenta(IBAN, cantidadRetirar);

                    if (retirada == true) {

                        System.out.println("----------------------------------------------------\n"
                                + "RETIRADA REALIZADA EN LA CUENTA ASOCIADA AL IBAN:\n "
                                + IBAN + "\n");
                        System.out.println("\n----------------------------------------------------\n"
                                + "SU SAlDO ACTUAL ES:: " + listaCuentas.obtenerSaldo(IBAN) + "\n");
                    } else if (retirada == false) {
//                        System.out.println("\n----------------------------------------------------\n"
//                                + "LA RETIRADA EN LA CUENTA ASOCIADA AL IBAN:\n "
//                                + IBAN + "\n"
//                                + "NO SE PUEDE REALIZAR POR FALTA DE FONDOS EN LA CUENTA");

                        System.out.println("\n----------------------------------------------------\n"
                                + "SU SAlDO ACTUAL ES:: " + listaCuentas.obtenerSaldo(IBAN) + "\n");
                    }

                    break;
                }

                ///////////Consultar el saldo actual de una cuenta//////////////
                case 6: {

                    String IBAN = Utilidades.compruebaIBAN();
                    boolean existeIBAN = listaCuentas.existeIBAN(IBAN);

                    if (existeIBAN == true) {
                        double saldo = listaCuentas.obtenerSaldo(IBAN);

                        System.out.println("\n----------------------------------------------------\n"
                                + "EL SALDO DE LA CUENTA CON IBAN " + IBAN + " ES DE: " + saldo
                                + "\n----------------------------------------------------\n");
                    }
                    if (existeIBAN == false) {
                        System.out.println("\n----------------------------------------------------\n"
                                + "ERROR!! NO SE ENCUENTRA LA CUENTA ASOCIADA AL IBAN:\n "
                                + "           " + IBAN
                                + "\n----------------------------------------------------\n");
                    }

                    break;
                }
                //////////////////Eliminar Cuenta Bancaria//////////////////////
                case 7: {
                    String IBAN = Utilidades.compruebaIBAN();
                    boolean existeIBAN = listaCuentas.existeIBAN(IBAN);
                    int indice = 0;

                    if (existeIBAN == true) {
                        indice = listaCuentas.dameIndice(IBAN);
                        listaCuentas.eliminaCuenta(indice);
                        System.out.println("\n----------------------------------------------------\n"
                                + "SE HA ELIMINADO LA CUENTA ASOCIADA AL IBAN:\n "
                                + "           " + IBAN
                                + "\n----------------------------------------------------\n");

                    }
                    if (existeIBAN == false) {
                        System.out.println("\n----------------------------------------------------\n"
                                + "ERROR!! NO SE ENCUENTRA LA CUENTA ASOCIADA AL IBAN: "
                                + "           " + IBAN
                                + "\n----------------------------------------------------\n");

                    }
                    break;
                }

                ///////////////Mostrar número de Cuentas Ahorro/////////////////
                case 8: {
                    System.out.println("\n----------------------------------------------------");
                    System.out.println("\n El de cuentas de Ahorro es: " + listaCuentas.numeroCuentasAhorro()
                            + "\n----------------------------------------------------\n");;

                    break;
                }

                /////Mostrar saldo acumulado de todas las Cuentas Corrientes////
                case 9: {
                    System.out.println("\n----------------------------------------------------");
                    System.out.println("\n El saldo acumulado en todas las cuentas es: "
                            + listaCuentas.calculaSaldoTotal()
                            + "\n----------------------------------------------------\n");
                    break;

                }

                ///////////////Mostrar las tres cuentas con mayor saldo/////////
                case 10: {
                    System.out.println("\n----------------------------------------------------\n"
                            + "   TRES PRIMERAS CUENTAS CON MAYOR SALDO\n"
                            + "----------------------------------------------------\n");
                    listaCuentas.tresMayorSaldo();
                    break;
                }
                //////////////////Listado de Clientes///////////////////////////
                case 11: {

                    listaCuentas.listadoClientes();

                    break;
                }
                //////////////////termina el programa///////////////////////////
                case 12: {

                    listaCuentas.guardaArray();

                    System.out.println("\n----------------------------------------------------");
                    System.out.println("----------------FIN DEL PROGRAMA-------------------");
                    System.out.println("----------------------------------------------------\n");

                    break;
                }

                ////////////////// Opcion por defecto //////////////////////////
                default: {
                    System.out.println("----------------------------------------------------");
                    System.out.println("      ERROR: INTRODUZCA UN NUMERO DEL 1 AL 11");
                    System.out.println("----------------------------------------------------\n");
                    break;
                }

            }//Fin Switch

        } while (opcion
                != 12);

    }// Fin Método principal    

    // Función: Pide String para introducir un nombre de cliente
    // Devuelve: Devuelve String nombre con el nombre introducido
    public static String dameNombre() {
        String nombre = "";
        boolean nombreOK = false;
        do {
            nombre = Utilidades.llegirString("----------------------------------------------------\n"
                    + "Introduzca nombre: ").toUpperCase();
            if (nombre.length() != 0) {
                nombreOK = true;
            }
            if (nombre.length() == 0) {
                System.out.println("\n----------------------------------------------------\n"
                        + "ERROR!! DEBE INTRODUCIR UN NOMBRE: ");
            }
        } while (nombreOK == false);

        return nombre;
    }

    // Función: Pide String para introducir los apellidos del cliente
    // Devuelve: Devuelve String apellidos con los apellidos introducidos
    public static String dameApellidos() {
        String apellidos = "";
        boolean apellidosOK = false;
        do {
            apellidos = Utilidades.llegirString("Introduzca apellidos: ").toUpperCase();
            if (apellidos.length() != 0) {
                apellidosOK = true;
            }
            if (apellidos.length() == 0) {
                System.out.println("\n----------------------------------------------------\n"
                        + "ERROR!! DEBE INTRODUCIR LOS APELLIDOS: ");
            }

        } while (apellidosOK == false);

        return apellidos;
    }

    // Función: Pide por consola un double como saldo inicial        
    // Devuelve: double saldoInicial con valor introducido   
    public static double dameSaldoInicial() {
        double saldoIncial = 0;
        boolean continua = false;

        do {
            try {

                saldoIncial = Utilidades.llegirDouble("Introduzca saldo inicial: ");
            } catch (InputMismatchException e) {
                System.out.println("----------------------------------------------------\n"
                        + "      ERROR: ENTRADA DE DATOS NO COMPATIBLE\n"
                        + "----------------------------------------------------");

            }

            if (saldoIncial > 0) {
                continua = true;

            }
            if (saldoIncial <= 0) {
                System.out.println("----------------------------------------------------\n"
                        + "      ERROR: DEBE INTRODUCIR UN VALOR POSITIVO\n"
                        + "----------------------------------------------------");
                continua = false;
            }

        } while (continua == false);

        return saldoIncial;
    }

    //Función: pide elección de tipo de cuenta por consola
    //Devuelve: int valor 1 o 2 en función del tipo de cuenta que se desea crear
    public static int tipoCuenta() {
        int tipoCuenta = 0;
        boolean opcion = false;

        do {
            try {
                tipoCuenta = Utilidades.llegirSencer("----------------------------------------------------\n"
                        + "Por favor elija una opción \n"
                        + "1. Cuenta Corriente\n"
                        + "2. Cuenta de Ahorro\n"
                        + "----------------------------------------------------\n");
            } catch (InputMismatchException e) {
                System.out.println("----------------------------------------------------\n"
                        + "      ERROR: SÓLO ADMITE OPCION 1 O 2\n"
                        + "----------------------------------------------------");

            }
            if (tipoCuenta == 1 | tipoCuenta == 2) {
                opcion = true;
            } else {
                System.out.println("----------------------------------------------------\n"
                        + "    ERROR: DEBE INTRODUCIR UNA OPCIÓN VÁLIDA\n"
                        + "----------------------------------------------------");

            }
        } while (opcion == false);

        return tipoCuenta;
    }

    //Función: crea un objeto CuentaCorriente con los parametros que le pasamos al método introducidos previamente
    //Devuelve: objeto CuentaCorriente con los valores introducidos por consola
    public static CuentaCorriente creaCuentaCorriente(Persona cliente, double saldoIncial, String IBAN) {
        CuentaCorriente cuentaCorriente = null;
        Persona persona = cliente;
        double sInicial = saldoIncial;
        String numIBAN = IBAN;
        boolean continuaComisionMantenimiento = false;
        double comisionMantenimiento = 0;
        boolean continuaTipoInteresDescubierto = false;
        double tipoInteresDescubierto = 0;
        boolean continuaMaximoDescubierto = false;
        double maximoDescubierto = 0;

        //////////Introduccion Válida de Comisión de mantenimiento//////////////
        do {
            try {
                comisionMantenimiento = Utilidades.llegirDouble("----------------------------------------------------\n"
                        + "INTRODUZCA LA COMISIÓN DE MANTENIMIENTO: ");
            } catch (InputMismatchException e) {
                System.out.println("----------------------------------------------------\n"
                        + "      ERROR: ENTRADA DE DATOS NO COMPATIBLE\n"
                        + "----------------------------------------------------");

            }

            if (comisionMantenimiento > 0) {
                continuaComisionMantenimiento = true;

            }
            if (comisionMantenimiento <= 0) {
                System.out.println("----------------------------------------------------\n"
                        + "      ERROR: DEBE INTRODUCIR UN VALOR POSITIVO\n"
                        + "----------------------------------------------------");
                continuaComisionMantenimiento = false;
            }
        } while (continuaComisionMantenimiento == false);

        /////////Introducion Válida de Tipo de Interes por Descubierto//////////
        do {
            try {
                tipoInteresDescubierto = Utilidades.llegirDouble(
                        "INTRODUZCA EL TIPO DE INTERES POR DESCUBIERTO: ");
            } catch (InputMismatchException e) {
                System.out.println("----------------------------------------------------\n"
                        + "      ERROR: ENTRADA DE DATOS NO COMPATIBLE\n"
                        + "----------------------------------------------------");

            }
            if (tipoInteresDescubierto > 0) {
                continuaTipoInteresDescubierto = true;

            }
            if (tipoInteresDescubierto <= 0) {
                System.out.println("----------------------------------------------------\n"
                        + "      ERROR: DEBE INTRODUCIR UN VALOR POSITIVO\n"
                        + "----------------------------------------------------");
                continuaComisionMantenimiento = false;

            }
        } while (continuaTipoInteresDescubierto == false);

        ////////////Introducción Válida de Máximo Descubierto///////////////////
        do {
            try {
                maximoDescubierto = Utilidades.llegirDouble(
                        "INTRODUZCA LA CANTIDAD MÁXIMA POR DESCUBIERTO: ");
            } catch (InputMismatchException e) {
                System.out.println("----------------------------------------------------\n"
                        + "      ERROR: ENTRADA DE DATOS NO COMPATIBLE\n"
                        + "----------------------------------------------------");

            }
            if (maximoDescubierto > 0) {
                continuaMaximoDescubierto = true;

            }
            if (maximoDescubierto <= 0) {
                System.out.println("----------------------------------------------------\n"
                        + "      ERROR: DEBE INTRODUCIR UN VALOR POSITIVO\n"
                        + "----------------------------------------------------");

                continuaMaximoDescubierto = false;
            }

        } while (continuaMaximoDescubierto == false);

        try {
            cuentaCorriente = new CuentaCorriente(persona, sInicial, numIBAN, comisionMantenimiento, tipoInteresDescubierto, maximoDescubierto);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return cuentaCorriente;
    }

    //Función: crea un objeto CuentaAhorro con los parametros que le pasamos al método introducidos previamente
    //Devuelve: objeto CuentaAhorro con los valores introducidos por consola
    public static CuentaAhorro creaCuentaAhorro(Persona cliente, double saldoInicial, String IBAN) {

        CuentaAhorro cuentaAhorro = null;
        Persona persona = cliente;
        double sInicial = saldoInicial;
        double tipoInteresAnual = 0;
        String numIBAN = IBAN;
        boolean continuaTipoInteresAnual = false;
        do {
            try {
                tipoInteresAnual = Utilidades.llegirDouble("----------------------------------------------------\n"
                        + "INTRODUZCA EL TIPO DE INTERES ANUAL:  ");

            } catch (InputMismatchException e) {
                System.out.println("----------------------------------------------------\n"
                        + "      ERROR: ENTRADA DE DATOS NO COMPATIBLE\n"
                        + "----------------------------------------------------");

            }
            if (tipoInteresAnual > 0) {
                continuaTipoInteresAnual = true;
            }
            if (tipoInteresAnual <= 0) {
                System.out.println("----------------------------------------------------\n"
                        + "      ERROR: DEBE INTRODUCIR UN VALOR POSITIVO\n"
                        + "----------------------------------------------------");

                continuaTipoInteresAnual = false;
            }

        } while (continuaTipoInteresAnual == false);
        try {
            cuentaAhorro = new CuentaAhorro(persona, sInicial, numIBAN, tipoInteresAnual);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return cuentaAhorro;
    }

}//Fin Clase

