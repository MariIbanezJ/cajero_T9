package prog09;

import java.io.Serializable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Ejercicio Programa 9
 *
 * @author Juan Marí Ibáñez Fecha última modificación:20.03,2022
 */
public class Dni implements Serializable{

    // Cadena con las letras posibles del DNI ordenados para el cálculo de DNI
    private static final String LETRAS_DNI = "TRWAGMYFPDXBNJZSQVHLCKE";

    // Atributos de objeto para calculos del NIF
    private static int numDNI;

    private String Dni;

    //Contructor Dni
    public Dni(String DNI) {

       
        this.Dni = DNI;

    }

    // Método setter    
    public void setDNI(String DNI)  {
        

        this.Dni = DNI;

    }

    //Método getter
    public String getDNI() {
        return this.Dni;
    }

    // Función: Envia numero de DNI almacenado en numDNI        
    // Devuelve: variable int numDNI con el numero del DNI almacenado
    public static int obtenerDNI() {
        return numDNI;
    }

    // Función: establece el numero de DNI en la variable numDNI        
    // realiza comprobaciones para numero de DNI valido
    public static void establecer(String nif) throws Exception {
        if (validarNIF(nif)) { // Valor válido: lo almacenamos
            numDNI = extraerNumeroNIF(nif);
        } else { // Valor inválido: lanzamos una excepción
            throw new Exception("----------------------------------------------------\n"
                    + "                ERROR: EL DNI NO ES VALIDO\n"
                    + "----------------------------------------------------");
        }

    }

    public static void establecer(int dni) throws Exception {

        // Comprobación de rangos
        if (dni > 999999 && dni < 99999999) {
            numDNI = dni; // Valor válido: lo almacenamos
        } else { // Valor inválido: lanzamos una excepción
            throw new Exception("DNI inválido: " + String.valueOf(dni));
        }
    }

    // Función: Calcula letra DNI a partir de matriz de letras guardadas en 
    // constante String LETRAS_DNI   
    // Devuelve: variable char con letra DNI calculada
    private static char calcularLetraNIF(int dni) {
        char letra;

        // Cálculo de la letra NIF
        letra = LETRAS_DNI.charAt(dni % 23);

        // Devolución de la letra NIF
        return letra;
    }

    // Función: extrae la letra del NIF del DNI introducido por usuario        
    // Devuelve: de vuelve variable char letra con letra extraida de DNI
    private static char extraerLetraNIF(String nif) {
        char letra = nif.charAt(nif.length() - 1);

        return letra;
    }

    // Función: Extrae numero de NIF del DNI introducido por el usuario      
    // Devuelve: variable int numero con el numero extraido de DNI
    private static int extraerNumeroNIF(String nif) {
        int numero = Integer.parseInt(nif.substring(0, nif.length() - 1));
        return numero;
    }

    // Función: comprueba que el DNI introducido por el usuario es valido        
    // Devuelve: variable boolean para saber si es valdio o no el DNI introducido   
    public static boolean validarNIF(String nif) {
        boolean valido = true;   // Suponemos el NIF válido mientras no se encuentre algún fallo
        char letra_calculada;
        char letra_leida;
        int dni_leido;

        if (nif == null) {  // El parámetro debe ser un objeto no vacío
            valido = false;

            // La cadena debe estar entre 8(7+1) y 9(8+1) caracteres    
        } else if (nif.length() < 8 || nif.length() > 9) {
            valido = false;
        } else {
            // Extraemos la letra de NIF (letra)
            letra_leida = extraerLetraNIF(nif);
            //transforma letra a mayusculas para que el usuario pueda poner la 
            //letra tanto en minusculas como en mayusculas
            char letra_leida_Mayusculas = Character.toUpperCase(letra_leida);
            // Extraemos el número de DNI (int)
            dni_leido = extraerNumeroNIF(nif);
            // Calculamos la letra de NIF a partir del número extraído
            letra_calculada = calcularLetraNIF(dni_leido);
            // Comparamos la letra extraída con la calculada
            if (letra_leida_Mayusculas == letra_calculada) {
                // Todas las comprobaciones han resultado válidas. El NIF es válido.
                valido = true;
            } else {
                valido = false;
            }
        }

        return valido;
    }

    // Función: Pide String para introducir un DNI válido de cliente
    // Devuelve: Devuelve String DNI con el DNI válido introducido
    public static String dameDNI() {
        String DNI = "";
        boolean DNIValido = false;
        boolean continuaDNI = false;

        do {
            DNI = Utilidades.llegirString("Introduzca DNI: ").toUpperCase();

            DNIValido = validarNIF(DNI);

            if (DNIValido == true) {

                continuaDNI = true;
            }

            if (DNIValido == false) {
                System.out.println("\n----------------------------------------------------\n"
                        + "ERROR!! INTRODUZCA UN DNI VÁLIDO (11111111A): ");
                continuaDNI = false;
            }

        } while (continuaDNI == false);

        return DNI;
    }

}
