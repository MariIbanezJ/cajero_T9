package prog09;

import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Ejercicio Programa 9
 *
 * @author Juan Marí Ibáñez Fecha última modificación: 20.03.2022
 */
public class ListaCuentas {

    private ArrayList<CuentaBancaria> listaCuentas;// Lista Dinámica de cuentas(La variable Genérica debe ser una clase

    //Metodo Constructor por Defecto
    public ListaCuentas() {
        listaCuentas = new ArrayList<>();
    }

    //Método que crea y devuelve una copia del ArrayList original
    public ArrayList<CuentaBancaria> getCuentaBancaria() {
        ArrayList<CuentaBancaria> nuevaListaCuentas = new ArrayList<>();
        return nuevaListaCuentas;
    }

    // Método que crea un IBAN válido a partir de una expresión regular y comprueba que  sea unico
    //devuelve String IBAN
    public String crearIBAN() {
        String IBAN = "";
        Pattern patronIBAN = Pattern.compile("(ES[0-9]{22})");
        boolean continuaIBAN = false;

        do {
            IBAN = Utilidades.llegirString( //Lee por teclado el IBAN
                    "Introduzca IBAN: ").toUpperCase();
            Matcher coincidencia = patronIBAN.matcher(IBAN);

            if (IBAN.length() == 0) {//Si el valor introducido es 0 salta error
                System.out.println("\n----------------------------------------------------\n"
                        + "ERROR!! EL IBAN NO PUEDE QUEDAR VACÍO ");
                continuaIBAN = false;

            }

            if (coincidencia.matches()) {// Si el valor intoducido por teclado es coincide con el patron continúa
                if (listaCuentas.size() == 0) {//Si la lista esta vacía continua con el proceso
                    continuaIBAN = true;
                }
                if (listaCuentas.size() != 0) {//si hay elementos en la lista recorre la lista y busca si esta repetido

                    for (CuentaBancaria b : listaCuentas) {

                        if (b.getIBAN().equals(IBAN)) {//Si el IBAN está repetido salta error
                            System.out.println("\n----------------------------------------------------\n"
                                    + "ERROR!! YA EXISTE EL IBAN: " + IBAN + "\n POR FAVOR, INTRODUZCA OTRO IBAN");
                            continuaIBAN = false;

                        }
                        if (!b.getIBAN().equals(IBAN)) {// Si el valor no está repetido true
                            continuaIBAN = true;
                        }
                    }
                }
            } else {//Si el valor introducido no coincide con el patron salta error
                System.out.println("\n----------------------------------------------------\n"
                        + "ERROR!! INTRODUZCA UN IBAN VÁLIDO (ES1111111111111111111111: ");
                continuaIBAN = false;
            }

        } while (continuaIBAN == false);

        return IBAN;
    }

    //Metodo que comprueba si el IBAN existe en el ArrayList listaCuentas
    //devuelve boolean IBANOK con true o false
    public boolean existeIBAN(String IBAN) {
        boolean IBANOK = false;

        for (CuentaBancaria b : listaCuentas) {

            if (b.getIBAN().equals(IBAN)) {

                IBANOK = true;
            }

        }

        return IBANOK;

    }

    //Método que añade cuentas al ArrayList que recibe por parametro
    //Comprueba que no hayamos llegado al número máximo permitido
    public boolean abrirCuenta(CuentaBancaria nuevaCuentaBancaria) {
        listaCuentas.add(nuevaCuentaBancaria);

        return true;

    }

    // Método que recorree imprimelos datos de las cuentas almacenadas en cuentaBancaria
    // devuelve matriz listadoCuentas
    public void listadoCuentas() {
        if (listaCuentas.size() == 0) {
            System.out.println("\n----------------------------------------------------\n"
                    + "      EL LISTADO DE CUENTAS ESTÁ VACÍO "
                    + "\n----------------------------------------------------\n");
        }
        for (CuentaBancaria b : listaCuentas) {

            System.out.println("IBAN: " + b.getIBAN() + "\t NOMBRE: " + b.getTitular().getNombreCliente() + " "
                    + b.getTitular().getApellidosCliente() + "\t DNI: " + b.getTitular().getDNI().getDNI() + "\t SALDO: " + b.getSaldo());

        }

    }
    //Método que comprueba la información almacenada en la matriz cuentaBancaria
    //Devuelve un String informaciónCuenta con los datos que el método toString devuelve en la posición cuentaBancaria[i]

    public String informacionCuenta(String IBAN) {

        String informacionCuenta = null;

        for (CuentaBancaria b : listaCuentas) {
            if (b.getIBAN().equals(IBAN)) {
                informacionCuenta = "IBAN: " + b.getIBAN() + "\t NOMBRE: " + b.getTitular().getNombreCliente() + " "
                        + b.getTitular().getApellidosCliente() + "\t DNI: " + b.getTitular().getDNI().getDNI() + "\t SALDO: " + b.getSaldo();
            }

        }

        return informacionCuenta;
    }

    //Método que busca la posición mediante el IBAN de un elemento en el ArrayList
    //Devuelve un numero entero con la posición del elemento solicitado
    public int dameIndice(String IBAN) {
        int indice = 0;
        for (CuentaBancaria b : listaCuentas) {
            if (b.getIBAN().equals(indice)) {
                indice = listaCuentas.indexOf(b);
            }
        }

        return indice;
    }

    //Método que borra un elemento de la posición solicitada a traves de un int
    public void eliminaCuenta(int indice) {

        listaCuentas.remove(indice);

    }

    //Método que calcula el saldo acumulado de todas las cuentas
    public double calculaSaldoTotal() {
        double suma = 0;
        for (CuentaBancaria b : listaCuentas) {
            suma += b.getSaldo();
        }

        return suma;
    }

    //Método que devuelve el número total de cuentas tipo Ahorro
    public int numeroCuentasAhorro() {
        int numeroCuentasAhorro = 0;
        for (CuentaBancaria b : listaCuentas) {
            if (b instanceof CuentaAhorro) {
                numeroCuentasAhorro++;
            }
        }

        return numeroCuentasAhorro;
    }

    // Metodo que ingresa cantidades en una cuenta concreta almacenada en el ArrayList listaCuentas
    // devuelve un boolean infoIngreso para saber si se ha realizado correctamente o no
    public boolean ingresoCuenta(String IBAN, double cantidadIngresar) {

        boolean infoIngreso = false;

        double ingreso = cantidadIngresar;

        for (CuentaBancaria b : listaCuentas) {
            if (b.getIBAN().equals(IBAN)) {

                double saldo = b.getSaldo();
                double saldoActual = saldo + ingreso;
                b.setSaldo(saldoActual);
                infoIngreso = true;

            }

        }

        return infoIngreso;
    }

    // Metodo que retira cantidades en una cuenta concreta almacenada en el ArrayList listaCuentas
    // devuelve un boolean infoRetirada para saber si se ha realizado correctamente o no 
    public boolean retiradaCuenta(String IBAN, double cantidadRetirar) {

        boolean infoRetirada = false;

        double retirada = cantidadRetirar;

        for (CuentaBancaria b : listaCuentas) {

            if (b.getIBAN().equals(IBAN)) {//Si el IBAN existe continua con lo siguiente   
                infoRetirada = b.retirada(retirada);
            } else if (!b.getIBAN().equals(IBAN)) {
                infoRetirada = false;

            }

        }

        return infoRetirada;
    }

    // Metodo que informa del saldo acumulado en una cuenta concreta almacenada en el ArrayList listaCuentas
    // devuelve un double saldoACtual con la cantidad actual de fondos en la cuenta
    public double obtenerSaldo(String IBAN) {

        double saldoActual = 0;
        boolean existeIBAN = existeIBAN(IBAN);

        for (CuentaBancaria b : listaCuentas) {
            if (b.getIBAN().equals(IBAN)) {

                saldoActual = b.getSaldo();

            }

        }

        return saldoActual;
    }

    //Metodo que ordena listaCuentas de Mayor a Menor e imprime las tres primeras por pantalla
    public void tresMayorSaldo() {

        Collections.sort(listaCuentas);
        CuentaBancaria[] array = new CuentaBancaria[listaCuentas.size()];
        listaCuentas.toArray(array);

        //Si el array es menor de 3 continua con lo siguiente:
        if (array.length < 3) {

            for (int i = 0; i < array.length; i++) {

                System.out.println("IBAN: " + array[i].getIBAN() + "\t NOMBRE: " + array[i].getTitular().getNombreCliente()
                        + " " + array[i].getTitular().getApellidosCliente() + "\tDNI: " + array[i].getTitular().getDNI().getDNI() + "\t SALDO: " + array[i].getSaldo());
            }

            //Si el array list es mayor o igual a 3 continua con lo siguyiente:    
        } else if (array.length >= 3) {
            for (int i = 0; i < 3; i++) {
                System.out.println("IBAN: " + array[i].getIBAN() + "\t NOMBRE: " + array[i].getTitular().getNombreCliente()
                        + " " + array[i].getTitular().getApellidosCliente() + "\t DNI: " + array[i].getTitular().getDNI().getDNI() + "\t SALDO: " + array[i].getSaldo());
            }
        }

    }

    //Metodo que crea archivo binario a partir del ArrayList listaCuentas
    public void guardaArray() {

        try {

            FileOutputStream fichero = new FileOutputStream("datos_mari_ibanez.dat");//busca.crea fichero
            ObjectOutputStream guardaFichero = new ObjectOutputStream(fichero);//crea flujo
            guardaFichero.writeObject(listaCuentas);//escribe en el fichero el objeto que te paso
            guardaFichero.close();//cierra flujo
            fichero.close();
            System.out.println("Fichero Guardado");

        } catch(FileNotFoundException e){
            System.out.println(e.getMessage());
        }catch(IOException e){
            System.out.println(e.getMessage());
        }

    }

    //Metodo que carga el archivo binario creado a partir del ArrayList listaCuentas
    public void cargaArray() {

        FileInputStream fichero = null;
        try {
            fichero = new FileInputStream("datos_mari_ibanez.dat"); //busca fichero
            ObjectInputStream leeFichero;

            leeFichero = new ObjectInputStream(fichero); //crea flujo

            listaCuentas = (ArrayList<CuentaBancaria>) leeFichero.readObject();

            leeFichero.close();//cierra flujo
            fichero.close();
            
            if(fichero !=null){ 
            System.out.println("Fichero Cargado");
            }
            
        } catch(FileNotFoundException e){
            //System.out.println(e.getMessage());
        }catch(IOException e){
            System.out.println(e.getMessage());
        }catch (ClassNotFoundException e){
            System.out.println(e.getMessage());
        }
        
    }

    //Metodo que crea archivo texto a partir del ArrayList listaCuentas
    // y muestra por pantalla el listado de clientes (IBAN y Titular)
    public void listadoClientes() {

        //Escribe en el fichero
        FileWriter fichero = null;
        PrintWriter pwFichero;

        try {
            fichero = new FileWriter("datos_mari_ibanez.txt");
        } catch (IOException ex) {
            Logger.getLogger(ListaCuentas.class.getName()).log(Level.SEVERE, null, ex);
        }
        pwFichero = new PrintWriter(fichero);

        pwFichero.println("----------------------------------------------------\n"
                + "IBAN\t\t\tCliente\n"
                + "----------------------------------------------------");

        for (CuentaBancaria b : listaCuentas) {

            pwFichero.println(b.getIBAN() + "\t" + b.getTitular().getNombreCliente() + "  " + b.getTitular().getApellidosCliente());

        }

        // Numero de Cuentas Bancarias
        int numCuentas = 0;
        for (CuentaBancaria b : listaCuentas) {
            numCuentas++;
        }
        pwFichero.println("----------------------------------------------------\n" + "Numero de Cuentas: " + numCuentas);

        //Fecha del sistema
        pwFichero.println("----------------------------------------------------");
        Date fecha = new Date();
        pwFichero.println("Fecha: " + fecha);
        pwFichero.println("----------------------------------------------------\n");

        try {
            fichero.close();
        } catch (IOException ex) {
            Logger.getLogger(ListaCuentas.class.getName()).log(Level.SEVERE, null, ex);
        }

        //Lee del Fichero 
        try {
            FileReader frFichero = new FileReader("datos_mari_ibanez.txt");
            BufferedReader brFichero = new BufferedReader(frFichero);
            String linea = "";
            while (linea != null) {
                linea = brFichero.readLine();
                if (linea != null) {
                    System.out.println(linea);
                }
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ListaCuentas.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ListaCuentas.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}//Fin Clase

