package prog09;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Ejercicio 9 Clase Utilidades del programa de facturación Funciones: Leer
 * int, double, String por teclado y validar DNI
 *
 * @author Juan Marí Ibáñez Fecha última modificación:20.03,2022
 */
public class Utilidades {

    // Cadena con las letras posibles del DNI ordenados para el cálculo de DNI
    private static final String LETRAS_DNI = "TRWAGMYFPDXBNJZSQVHLCKE";

    // Atributos de objeto para calculos del NIF
    private static int numDNI;

    // Función: Lee entero por teclado
    // Devuelve: variable entero con entero introducido por usuario 
    public static int llegirSencer(String prompt) throws InputMismatchException {

        Scanner teclado = new Scanner(System.in);
        int entero = 0;

        System.out.print(prompt);
        entero = teclado.nextInt();
        return entero;
    }

    // Función: Lee doble por teclado
    // Devuelve: variable real con double introducido por usuario     
    public static double llegirDouble(String prompt) throws InputMismatchException {

        Scanner teclado = new Scanner(System.in);
        double real = 0;

        System.out.print(prompt);
        real = teclado.nextDouble();
        return real;
    }

    // Función: Lee cadena de texto por teclado
    // Devuelve: variable String con cadema introducida por usuario   
    public static String llegirString(String prompt) {

        Scanner teclado = new Scanner(System.in);
        String cadena;

        System.out.print(prompt);
        cadena = teclado.nextLine();
        return cadena;
    }

    
 // Método que crea un IBAN válido a partir de una expresión regular y comprueba que  sea unico
    //devuelve String IBAN
    public static String compruebaIBAN() {
        String IBAN = "";

        Pattern patronIBAN = Pattern.compile("(ES[0-9]{22})");
        boolean continuaIBAN = false;

        do {
            IBAN = Utilidades.llegirString( //Lee por teclado el IBAN
                    "Introduzca IBAN: ").toUpperCase();
            Matcher coincidencia = patronIBAN.matcher(IBAN);
            if (IBAN.length() == 0) {//Si el valor introducido es 0 salta error
                System.out.println("\n----------------------------------------------------\n"
                        + "ERROR!! EL IBAN NO PUEDE QUEDAR VACÍO ");
                continuaIBAN = false;

            }

            if (!coincidencia.matches()) {//Si el valor introducido no coincide con el patron salta error
                System.out.println("\n----------------------------------------------------\n"
                        + "ERROR!! INTRODUZCA UN IBAN VÁLIDO (ES1111111111111111111111: ");
                continuaIBAN = false;
            }

            if (IBAN.length() != 0 & coincidencia.matches()) {// si el valor introducido es diferente de 0 continua
                continuaIBAN = true;
            }

        } while (continuaIBAN == false);

        

        return IBAN;
    }

}//Fin Clase

