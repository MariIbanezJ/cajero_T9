package prog09;

import java.util.*;
import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Ejercicio 9 Programa Administración de cuentas bancarias Estudio:
 * Composición, Herencia, Clases Abstractas, Interfaces.
 *
 * @author Juan Marí Ibáñez Fecha última modificación: 20.03,2022
 */
public abstract class CuentaBancaria implements Comparable<CuentaBancaria>, Serializable {

    protected Persona titular;
    protected double saldo;
    protected String IBAN;

//Métodos constructores
//Método constructor por defecto
    public CuentaBancaria() {

    }

//Método constructor con parámetros
    public CuentaBancaria(Persona titular, double saldo, String IBAN) throws Exception {
        if (validaIBAN(IBAN) == false) {
            throw new Exception("\n----------------------------------------------------\n"
                    + "IBAN INTRODUCIDO NO VÁLIDO. NO SE HA GUARDADO EL VALOR ");
        }

        this.titular = new Persona(titular.getNombreCliente(),titular.getApellidosCliente(), titular.getDNI());
        this.saldo = saldo;
        this.IBAN = IBAN;

    }
 

//Métodos Setter
    public void setTitular(Persona titular)throws Exception {
        if (validaIBAN(IBAN) == false) {
            throw new Exception("\n----------------------------------------------------\n"
                    + "IBAN INTRODUCIDO NO VÁLIDO. NO SE HA GUARDADO EL VALOR ");
        }
        
        this.titular = new Persona(titular.getNombreCliente(),titular.getApellidosCliente(), titular.getDNI());
       
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public void setIBAN(String IBAN) throws Exception {
        if (validaIBAN(IBAN) == false) {
            throw new Exception("\n----------------------------------------------------\n"
                    + "IBAN INTRODUCIDO NO VÁLIDO. NO SE HA GUARDADO EL VALOR ");
        }
       
        this.IBAN = IBAN;
    }

//Métodos Getter
    public Persona getTitular() {
        Persona titularCopia=null;
        try{
           titularCopia=new Persona(titular.getNombreCliente(),titular.getApellidosCliente(), titular.getDNI());
        }catch (Exception e){
            System.out.println(e.getMessage());
        }        
        return titularCopia;
    }

    public double getSaldo() {
        return saldo;
    }

    public String getIBAN() {
        return IBAN;
    }

//Metodo recibe IBAN y valida patrón
//Devuelve String IBANOk con IBAN validado
    public boolean validaIBAN(String IBAN) {
        Pattern patronIBAN = Pattern.compile("(ES[0-9]{22})");
        Matcher coincidencia = patronIBAN.matcher(IBAN);
        boolean IBANOk = false;
        if (coincidencia.matches()) {
            IBANOk = true;
        } else if (!coincidencia.matches()) {
            IBANOk = false;
        }
        return IBANOk;
    }

    //Método Abstracto Retirada
    public abstract boolean retirada(double importe);

//Método toString
    @Override
    public String toString() {
        return "\t titular: " + titular + "\t saldo: " + saldo;
    }

    //Metodo Comparador
    @Override
    public int compareTo(CuentaBancaria b) {

        if (this.getSaldo() < b.getSaldo()) {
            return 1;
        } else if (this.getSaldo() > b.getSaldo()) {
            return -1;
        } else {
            return 0;

        }
    }
}//Fin Clase

