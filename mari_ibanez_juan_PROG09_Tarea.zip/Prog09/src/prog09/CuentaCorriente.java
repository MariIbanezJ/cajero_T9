package prog09;

/**
 * Ejercicio 9 Programa Administración de cuentas bancarias Estudio:
 * Composición, Herencia, Clases Abstractas, Interfaces. Clase que Cuenta
 * Corriente que hereda de CuentaBancaria
 *
 * @author Juan Marí Ibáñez Fecha última modificación: 20.03,2022
 */
public class CuentaCorriente extends CuentaBancaria {

    private double comisionMantenimiento;
    private double tipoInteresDescubierto;
    private double maximoDescubierto;

//Métodos constructores    
//Método constructor por defecto
    public CuentaCorriente() {

    }

//Método constructor subclase
    public CuentaCorriente(double comisionMantenimiento,
            double tipoInteresDescubierto, double maximoDescubierto) {
        this.comisionMantenimiento = comisionMantenimiento;
        this.tipoInteresDescubierto = tipoInteresDescubierto;
        this.maximoDescubierto = maximoDescubierto;
    }

//Método constructor superclase
    public CuentaCorriente(Persona titular, double saldo, String IBAN,
            double comisionMantenimiento, double tipoInteresDescubierto,
            double maximoDescubierto) throws Exception {
        
        super(titular, saldo, IBAN);
       
        this.comisionMantenimiento = comisionMantenimiento;
        this.tipoInteresDescubierto = tipoInteresDescubierto;
        this.maximoDescubierto = maximoDescubierto;
    }

//Métodos Setter
    public void setComisionMantenimiento(double comisionMantenimiento) {
        this.comisionMantenimiento = comisionMantenimiento;
    }

    public void setTipoInteresDescubierto(double tipoInteresDescubierto) {
        this.tipoInteresDescubierto = tipoInteresDescubierto;
    }

    public void setMaximoDescubierto(double maximoDescubierto) {
        this.maximoDescubierto = maximoDescubierto;
    }

//Métodos Getter
    public double getComisionMantenimiento() {
        return comisionMantenimiento;
    }

    public double getTipoInteresDescubierto() {
        return tipoInteresDescubierto;
    }

    public double getMaximoDescubierto() {
        return maximoDescubierto;
    }

//Método Retirada
    @Override
    public boolean retirada(double importe) {
        boolean retiradaOK = false;
        double retirada = importe;
        
        if (this.getSaldo() - importe >= -maximoDescubierto) {
            this.setSaldo(this.getSaldo() - importe);
            retiradaOK = true;
        }
        else if (this.getSaldo() - importe < - maximoDescubierto) {
            System.out.println("\n----------------------------------------------------\n"
                                + "LA RETIRADA EN LA CUENTA ASOCIADA AL IBAN:\n "
                                + CuentaCorriente.super.getIBAN() + "\n"
                                + "NO SE PUEDE REALIZAR. SUPERA EL MÁXIMNO DESCUBIERTO");
            
            retiradaOK = false;
        }

        return retiradaOK;

    }

//Método toString
    @Override
    public String toString() {
        return super.toString()
                + "\t comisionMantenimiento: " + comisionMantenimiento
                + "\t tipoInteresDescubierto: " + tipoInteresDescubierto
                + "\t maximoDescubierto: " + maximoDescubierto;
        //añadir atributos cuenta bancaria
    }

}//Fin Clase
