package prog09;

/**
 * Ejercicio 9 Programa Administración de cuentas bancarias Estudio:
 * Composición, Herencia, Clases Abstractas, Interfaces.
 * Clase que hereda de CuentaBancaria
 * @author Juan Marí Ibáñez Fecha última modificación: 20.03,2022
 */
public class CuentaAhorro extends CuentaBancaria {

    private double tipoInteresAnual;

//Métodos Constructores
//Método Constructor por defecto
    public CuentaAhorro() {

    }

//Método construcor con parámetros subclase
    public CuentaAhorro(double tipoInteresAnual) {
        this.tipoInteresAnual = tipoInteresAnual;
    }

//Método construcor con parámetros superclase 
    public CuentaAhorro(Persona titular, double saldo, String IBAN, double tipoInteresAnual) throws Exception {
        super(titular, saldo, IBAN);
        this.tipoInteresAnual = tipoInteresAnual;
    }

//Método Setter
    public void setTipoInteresAnual(double tipoInteresAnual) {
        this.tipoInteresAnual = tipoInteresAnual;
    }

//Método Getter
    public double getTipoInteresAnual() {
        return tipoInteresAnual;
    }

//Método Retirada
    @Override
    public boolean retirada(double importe) {       
        boolean retiradaOK=false;
        double retirada = importe;
        
        if(this.getSaldo()-importe>=0){
            this.setSaldo(this.getSaldo()-importe);
            retiradaOK=true;
        }else if (this.getSaldo()-importe<0){
            System.out.println("\n----------------------------------------------------\n"
                                + "LA RETIRADA EN LA CUENTA ASOCIADA AL IBAN:\n "
                                + CuentaAhorro.super.getIBAN() + "\n"
                                + "NO SE PUEDE REALIZAR POR FALTA DE FONDOS EN LA CUENTA");
            retiradaOK=false;
        }
        
        return retiradaOK;
       
    }
    
//Método to String
    @Override
    public String toString() {
        return super.toString()+ "\t Tipo de interes anual: " + tipoInteresAnual;
        //añadir atributos cuenta bancaria
    }

    

}//Fin Clase
