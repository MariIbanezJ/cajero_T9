package prog09;

import java.io.Serializable;

/**
 *Ejercicio 9
 *Programa  Administración de cuentas bancarias
 *Estudio: Composición, Herencia, Clases Abstractas, Interfaces.
 *@author Juan Marí Ibáñez
 *Fecha última modificación: 20.03,2022
 */

public class Persona implements Serializable{

    
    private String NombreCliente;
    private String ApellidosCliente;
    private Dni DNI;
    
    
    
//Métodos constructores
    
//Contructor por defecto
    public Persona(){
    
    }

//Contructor con parámetros
    public Persona(String NombreCliente, String ApellidosCliente, Dni DNI) throws Exception {
        if (Dni.validarNIF(DNI.getDNI())==false){
            throw new Exception("\n----------------------------------------------------\n"
                    + "DNI INTRODUCIDO NO VÁLIDO. NO SE HA GUARDADO EL VALOR ");
        }
        this.NombreCliente = NombreCliente;
        this.ApellidosCliente = ApellidosCliente;
        this.DNI = DNI;
    }    
    
//Métodos Setters
    
    public void setNombreCliente(String NombreCliente) {
        this.NombreCliente = NombreCliente;
    }

    public void setApellidosCliente(String ApellidosCliente) {
        this.ApellidosCliente = ApellidosCliente;
    }

    public void setDNI(Dni DNI)  throws Exception{
        if (Dni.validarNIF(DNI.getDNI())==false){
            throw new Exception("\n----------------------------------------------------\n"
                    + "DNI INTRODUCIDO NO VÁLIDO. NO SE HA GUARDADO EL VALOR ");
        }
        this.DNI = DNI;
    }
 
//Métodos Getters

    public String getNombreCliente() {
        return NombreCliente;
    }

    public String getApellidosCliente() {
        return ApellidosCliente;
    }

    public Dni getDNI() {
        return DNI;
    }

//Método toString
    @Override
    public String toString() {
        return  "Titular: " + NombreCliente + " "+ApellidosCliente + "\t DNI: " + DNI ;
    }
    
    

}//Fin Clase
